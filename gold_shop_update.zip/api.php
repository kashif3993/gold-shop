<?php

use App\Http\Controllers\Api\V1\ItemController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->middleware('auth:sanctum')->group(function () {
    Route::get('/items/search', [ItemController::class, 'search']);
    Route::post('/items', [ItemController::class, 'store']);
});
