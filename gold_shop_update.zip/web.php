<?php

use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return redirect()->route('dashboard');
})->name('home');

Route::middleware(['auth'])->group(function () {
    Route::get('dashboard', DashboardController::class)->name('dashboard');
    
    Route::get('inventory', [\App\Http\Controllers\InventoryController::class, 'index'])->name('inventory.index');
    
    Route::get('items/create', [\App\Http\Controllers\ItemController::class, 'create'])->name('items.create');
    Route::get('pos', function () {
        return inertia('pos/index', [
            'metals' => \App\Models\MetalType::all(),
            'purities' => \App\Models\Purity::all()
        ]);
    })->name('pos.index');

    Route::post('items', [\App\Http\Controllers\ItemController::class, 'store'])->name('items.store');
    Route::get('items/{item}/tag', [\App\Http\Controllers\ItemController::class, 'tag'])->name('items.tag');
    Route::get('items/{item}/edit', [\App\Http\Controllers\ItemController::class, 'edit'])->name('items.edit');
    Route::put('items/{item}', [\App\Http\Controllers\ItemController::class, 'update'])->name('items.update');
    Route::delete('items/{item}', [\App\Http\Controllers\ItemController::class, 'destroy'])->name('items.destroy');

    // POS API Routes
    Route::post('api/v1/pos/transaction', [\App\Http\Controllers\POSController::class, 'store'])->name('pos.transaction.store');
    Route::get('api/v1/items/search', [\App\Http\Controllers\Api\V1\ItemController::class, 'search'])->name('items.search');
});

require __DIR__.'/settings.php';
require __DIR__.'/auth.php';
